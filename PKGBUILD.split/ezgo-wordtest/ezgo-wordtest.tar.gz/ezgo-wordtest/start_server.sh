#!/bin/sh
xdg-open http://localhost:8888/ &
python -m SimpleHTTPServer 8888
