Frontend
========

FrontEnd for Word Test in Ezgo.

## start\_server.sh

Because chrome cannot load local files, before using chrome to view this project in local site,
execute start\server.sh to start a local server with port 8888, and the link would be http://localhost:8888/

*python is required*

## Hierarchy of layout

.  
└── index.html  
    ├── option.html  
    ├── quest.html  
    │   ├── quest-horizontal.html  
    │   ├── quest-horizontal2.html  
    │   └── quest-vertical.html  
    └── grade.html  
